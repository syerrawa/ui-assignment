import {Component, OnInit} from '@angular/core';
import {FormBuilder} from '@angular/forms';
import {DataService} from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  selectedRows;
  showCreateAssetModal = false;
  showModifyAssetModal = false;
  enableModify = false;
  gridApi;
  cols = [
    {field: 'id', header: 'Id'},
    {field: 'deviceType', header: 'Device Type'},
    {field: 'serialNumber', header: 'Serial Number'},
    {field: 'dateOfMfg', header: 'Date of Manufacture'},
    {field: 'modelNumber', header: 'Model Number'},
    {field: 'health', header: 'Health'},
    {field: 'status', header: 'Status'}
  ];
  columnDefs = [
    {
      headerName: 'Device Type',
      field: 'deviceType',
      sortable: true,
      filter: true
    },
    {
      headerName: 'Serial Number',
      field: 'serialNumber',
      sortable: true,
      filter: true
    },
    {
      headerName: 'Health',
      field: 'health',
      sortable: true,
      filter: true,
      cellRenderer: this.healthIndicator
    },
    {
      headerName: 'Status',
      field: 'status',
      sortable: true,
      filter: true
    },
    {
      headerName: 'Date of Manufacture',
      field: 'dateOfMfg',
      sortable: true,
      filter: true,
      valueFormatter: 'new Date(value).toLocaleDateString()'
    }

  ];

  rowData = [];

  constructor(private dataService: DataService) {
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.dataService.getAssets().subscribe(
      response => {
        this.rowData = response;
      }
    );
  }

  onSelectionChanged(params) {
    this.selectedRows = params.api.getSelectedRows();
    this.enableModify = this.selectedRows.length >= 0;
    console.log(this.selectedRows[0].id);
  }

  onCreateAsset(status: boolean) {
    this.showCreateAssetModal = false;
    if (status) {
      // display success toast
    } else {
      // display failure toast
    }
  }

  onModifyAsset(status: boolean) {
    this.showModifyAssetModal = false;
    if (status) {
      // display success toast
    } else {
      // display failure toast
    }
  }

  /*
   * Show a green indicator if the health of the device is good.
   * Show a red indicator if the health of the device is bad
   */
  healthIndicator(params: any): string {
    let cellContent: string;
    cellContent = params.value === 'good' ? '<div style=\'border-radius: 50%; height: 15px; width: 15px; background: #28a745;\'></div>' : '<div style=\'border-radius: 50%; height: 15px; width: 15px; background: #dc3545;\'></div>';
    return cellContent;
  }
}
