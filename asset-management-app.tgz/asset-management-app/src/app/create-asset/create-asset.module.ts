import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateAssetComponent } from './create-asset.component';
import {ReactiveFormsModule} from '@angular/forms';
import {DataService} from '../data.service';

@NgModule({
  declarations: [CreateAssetComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports: [
    CreateAssetComponent
  ],
  providers: [DataService]
})
export class CreateAssetModule { }
