import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {DataService} from '../data.service';

@Component({
  selector: 'app-create-asset',
  templateUrl: './create-asset.component.html',
  styleUrls: ['./create-asset.component.scss']
})
export class CreateAssetComponent implements OnInit {

  @Output()
  status = new EventEmitter<boolean>();

  assetForm: FormGroup;

  devices = ['MacBook', 'iPhone', 'iPad', 'MacPro', 'iMac'];

  constructor(private formBuilder: FormBuilder, private dataService: DataService) {
  }

  ngOnInit() {

    this.assetForm = this.formBuilder.group({
      serialNumber: ['', Validators.required],
      dateOfMfg: ['', Validators.required],
      modelNumber: ['', Validators.required],
      health: ['good', Validators.required],
      status: ['Un-Assigned'],
      deviceType: ['', Validators.required]
    });

  }

  onSubmit() {
    console.log(this.assetForm.value);
    this.dataService.createAsset().subscribe(
      response => {
        console.log('Asset created');
        this.status.emit(true);
      },
      error => {
        console.error(error);
        this.status.emit(false);
      }
    );
  }
}
