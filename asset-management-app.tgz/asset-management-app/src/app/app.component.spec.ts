import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import {AgGridModule} from 'ag-grid-angular';
import {DialogModule} from 'primeng/dialog';
import {CreateAssetModule} from './create-asset/create-asset.module';
import {ModifyAssetModule} from './modify-asset/modify-asset.module';
import {DataService} from './data.service';
import {HttpClientModule} from '@angular/common/http';
import {By} from '@angular/platform-browser';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AgGridModule.withComponents([]),
        DialogModule,
        CreateAssetModule,
        ModifyAssetModule,
        HttpClientModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        DataService
      ]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('the grid has rendered and visible', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const de = fixture.debugElement.query(By.css('.ag-theme-balham'));
    expect(de).toBeTruthy();
  });

  it('the grid data is available', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    fixture.whenRenderingDone().then(
      data => {
        const app = fixture.debugElement.componentInstance;
        console.log(app.rowData);
        expect(app.rowData.length).toBeGreaterThan(0);
      }
    );
  });
});
