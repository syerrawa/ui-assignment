import { Injectable } from '@angular/core';
import {Observable, of} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpClient: HttpClient) { }

  getAssets(): Observable<any> {
    return this.httpClient.get('./assets/mock/assets.json');
  }

  createAsset() {
    /*
     * Service method implementation to create an asset using http methods.
     */
    return of(undefined);
  }

  modifyAsset() {
    /*
     * Service method implementation to modify an asset using http methods.
     */
    return of(undefined);
  }

  getUsers(): Observable<any> {
    return this.httpClient.get('./assets/mock/users.json');
  }
}
