import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Observable} from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {DataService} from '../data.service';

@Component({
  selector: 'app-modify-asset',
  templateUrl: './modify-asset.component.html',
  styleUrls: ['./modify-asset.component.scss']
})
export class ModifyAssetComponent implements OnInit {

  @Input()
  selectedRows;

  @Output()
  status = new EventEmitter<boolean>();

  modifyAssetForm: FormGroup;
  users = [];

  userName;
  constructor(private formBuilder: FormBuilder, private dataService: DataService) {
  }

  ngOnInit() {

    // Call to fetch users from data service
    this.dataService.getUsers().subscribe(
      response => {
        this.users = response;
      }
    );

    let health;
    let status;
    if (this.selectedRows && this.selectedRows[0]) {
      health = this.selectedRows[0].health;
      status = this.selectedRows[0].status;
    }

    this.modifyAssetForm = this.formBuilder.group({
      health: [health, Validators.required],
      status: [status, Validators.required]
    });

  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => this.users.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1))
    )

  onSubmit() {
    console.log(this.modifyAssetForm.value);
    this.dataService.modifyAsset().subscribe(
      response => {
        console.log('Asset modified');
        this.status.emit(true);
      },
      error => {
        console.error(error);
        this.status.emit(false);
      }
    );
  }
}
