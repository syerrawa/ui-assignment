import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModifyAssetComponent } from './modify-asset.component';
import {DataService} from '../data.service';
import {NgbTypeaheadModule} from '@ng-bootstrap/ng-bootstrap';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [ModifyAssetComponent],
  imports: [
    CommonModule,
    NgbTypeaheadModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [
    ModifyAssetComponent
  ],
  providers: [DataService]
})
export class ModifyAssetModule { }
