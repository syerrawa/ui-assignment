## Steps to build and run the app on local

1) Run `npm install | npm i` in the root directory of the project to download all the dependencies.
2) Run `ng serve | ng s`.
3) This should get the app running on local.
4) Launch a browser with URL http://localhost:4200
5) Implementations of the write operations have been left blank intentionally since there isn't any backend system available.
6) Run `ng test` to see the test results.
